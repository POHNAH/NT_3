Action()
{

	web_add_cookie("SRCHUID=V=2&GUID=EA7378CEFCBD4013A5E5B3F166B6C26A&dmnchg=1; DOMAIN=www.bing.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=www.bing.com");

	web_add_cookie("_EDGE_V=1; DOMAIN=www.bing.com");

	web_add_cookie("MUID=092CDF2B1D8F6DFE2AABD1BA1CA76C37; DOMAIN=www.bing.com");

	web_add_cookie("SRCHUSR=DOB=20200318; DOMAIN=www.bing.com");

	web_add_cookie("MUIDB=092CDF2B1D8F6DFE2AABD1BA1CA76C37; DOMAIN=www.bing.com");

	web_url("webtours", 
		"URL=http://localhost:1080/webtours/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://www.bing.com/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_add_cookie("SRCHUID=V=2&GUID=B8CC5E51B78848CAA8BFF19511524A82&dmnchg=1; DOMAIN=www.microsoft.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=www.microsoft.com");

	web_add_cookie("_EDGE_V=1; DOMAIN=www.microsoft.com");

	web_add_cookie("MUID=01DC74B416E66B8527BA64B117346AE3; DOMAIN=www.microsoft.com");

	web_add_cookie("SRCHUSR=DOB=20210325; DOMAIN=www.microsoft.com");

	web_add_cookie("SRCHHPGUSR=SRCHLANGV2=ru; DOMAIN=www.microsoft.com");

	web_url("fwlink", 
		"URL=https://go.microsoft.com/fwlink/?LinkId=838604", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("SRCHUID=V=2&GUID=B8CC5E51B78848CAA8BFF19511524A82&dmnchg=1; DOMAIN=ieonline.microsoft.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=ieonline.microsoft.com");

	web_add_cookie("_EDGE_V=1; DOMAIN=ieonline.microsoft.com");

	web_add_cookie("MUID=01DC74B416E66B8527BA64B117346AE3; DOMAIN=ieonline.microsoft.com");

	web_add_cookie("SRCHUSR=DOB=20210325; DOMAIN=ieonline.microsoft.com");

	web_add_cookie("SRCHHPGUSR=SRCHLANGV2=ru; DOMAIN=ieonline.microsoft.com");

	web_add_cookie("MUIDB=01DC74B416E66B8527BA64B117346AE3; DOMAIN=ieonline.microsoft.com");

	web_add_cookie("SRCHUID=V=2&GUID=B8CC5E51B78848CAA8BFF19511524A82&dmnchg=1; DOMAIN=c.urs.microsoft.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=c.urs.microsoft.com");

	web_add_cookie("_EDGE_V=1; DOMAIN=c.urs.microsoft.com");

	web_add_cookie("MUID=01DC74B416E66B8527BA64B117346AE3; DOMAIN=c.urs.microsoft.com");

	web_add_cookie("SRCHUSR=DOB=20210325; DOMAIN=c.urs.microsoft.com");

	web_add_cookie("SRCHHPGUSR=SRCHLANGV2=ru; DOMAIN=c.urs.microsoft.com");

	web_add_header("UA-CPU", 
		"AMD64");

	web_url("fwlink_2", 
		"URL=https://go.microsoft.com/fwlink/?LinkId=251136", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://c.urs.microsoft.com/l1.dat?v=3&cv=9.11.18362.0&os=10.0.18363.0.0&pg=4A72F430-B40C-4D36-A068-CE33ADA5ADF9", "Referer=", ENDITEM, 
		LAST);

	return 0;
}